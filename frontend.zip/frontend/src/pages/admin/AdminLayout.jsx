import { Navigate, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { clearToken, getToken } from '../../services/api'

const link = ({ isActive }) =>
  `rounded-lg px-3 py-2 text-sm font-medium transition ${
    isActive ? 'bg-brand-50 text-brand-800' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
  }`

export default function AdminLayout() {
  const navigate = useNavigate()
  if (!getToken()) return <Navigate to="/admin/login" replace />

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-3">
          <span className="mr-4 font-extrabold text-brand-800">Admin<span className="text-accent-500">.</span></span>
          <NavLink to="/admin" end className={link}>Produtos</NavLink>
          <NavLink to="/admin/categorias" className={link}>Categorias</NavLink>
          <button onClick={() => { clearToken(); navigate('/admin/login') }}
            className="ml-auto text-sm font-medium text-slate-500 hover:text-slate-900">Sair</button>
        </div>
      </header>
      <main className="page"><Outlet /></main>
    </div>
  )
}
