import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { adminLogin, setToken } from '../../services/api'

export default function AdminLogin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [erro, setErro] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function submit(e) {
    e.preventDefault()
    setErro('')
    setLoading(true)
    try {
      const r = await adminLogin(email, password)
      setToken(r.token)
      navigate('/admin')
    } catch (err) {
      setErro(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-brand-800 to-brand-900 px-4">
      <form onSubmit={submit} className="card w-full max-w-sm space-y-4 p-6">
        <div>
          <p className="text-sm font-semibold text-brand-700">Encomendas<span className="text-accent-500">.</span></p>
          <h1 className="text-xl font-bold">Entrar como administrador</h1>
        </div>
        {erro && <p className="alert-error">{erro}</p>}
        <label className="label">Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input" />
        </label>
        <label className="label">Palavra-passe
          <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input" />
        </label>
        <button disabled={loading} className="btn-primary w-full">{loading ? 'A entrar...' : 'Entrar'}</button>
      </form>
    </div>
  )
}
