import { Link, NavLink } from 'react-router-dom'

// Categorias provisórias; na Sprint 2 passam a vir de GET /api/categories
const categorias = [
  { slug: 'telefones', nome: 'Telefones' },
  { slug: 'acessorios-eletronicos', nome: 'Acessórios Eletrónicos' },
  { slug: 'pastas-bolsinhas', nome: 'Pastas (Bolsinhas)' },
]

const pill = ({ isActive }) =>
  `rounded-full px-3 py-1.5 text-sm font-medium transition ${
    isActive ? 'bg-accent-500 text-slate-900' : 'text-brand-100 hover:bg-brand-800 hover:text-white'
  }`

export default function Header() {
  return (
    <header className="sticky top-0 z-10 bg-brand-900 shadow-md">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
        <Link to="/" className="text-xl font-extrabold tracking-tight text-white">
          Encomendas<span className="text-accent-400">.</span>
        </Link>
        <nav className="flex flex-wrap gap-1">
          {categorias.map((c) => (
            <NavLink key={c.slug} to={`/categoria/${c.slug}`} className={pill}>{c.nome}</NavLink>
          ))}
        </nav>
      </div>
    </header>
  )
}
